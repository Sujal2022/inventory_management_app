import 'dart:ui';

class MyColors
{

 /* static const lightgreen = Color(0xff37981d);
  static const darkgreen = Color(0xff0be32a);*/

  static const primarygrey = Color(0xfff2f6f5);
  static const primaryColor = Color(0xffc117e2);
  static const primaryColor1 = Color(0xff6f237e);
  static const orangeTile = Color(0xffffe1bb);
  static const orangeDivider = Color(0xffffc77e);
  static const contactDivider = Color(0xffd848ed);
  static const drawalDivider = Color(0xff881776);
  static const drawalBackground = Color(0xff141414);
}